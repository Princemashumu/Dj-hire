import DJ from "./DJ";
import Util from "./Util";
import MyEvent from "./MyEvent";
import Organizer from "./Organizer";
import Invitation from "./Invitation";

export default () => {
    DJ()
    Util()
    MyEvent()
    Organizer()
    Invitation()
}