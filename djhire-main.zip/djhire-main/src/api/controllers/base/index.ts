import BaseController from "./base";
import response_wrap from "../../../helpers/response-wrap";

export default new BaseController(response_wrap);