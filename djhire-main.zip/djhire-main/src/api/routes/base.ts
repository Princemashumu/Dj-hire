import { Application } from "express";

import baseController from "../controllers/base";

export default (app: Application) => {
}